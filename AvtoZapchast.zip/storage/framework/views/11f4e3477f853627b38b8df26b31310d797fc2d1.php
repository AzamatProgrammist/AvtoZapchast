

<?php $__env->startSection('title'); ?>
    Do'kon
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12 col-md-12 col-lg-12">
      
        <?php echo csrf_field(); ?>
      <div class="card">
          <div class="card-header">
            <h4>Do'kon</h4>
            <a href="<?php echo e(route('admin.shops.index')); ?>" class="btn btn-primary">Orqaga</a>
          </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table">
              <tr>
                <th>Nomi</th><td><?php echo e($shop->name_uz); ?></td>
              </tr>
              <tr>
                <th>Admini</th><td><?php echo e($shop->admin); ?></td>
              </tr>
              <tr>
                <th>Phone</th>
                <td>
                  <?php echo e($shop->user->phone); ?>

                </td>
              </tr>
              <tr>
                <th>Qo'shilgan vaqti</th><td><?php echo e($shop->created_at); ?></td>
              </tr>
            </table>
          </div>
        </div>
      </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\AvtoZapchast\resources\views/admin/shops/show.blade.php ENDPATH**/ ?>
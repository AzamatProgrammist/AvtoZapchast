

<?php $__env->startSection('title'); ?>
    Tavar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12 col-md-12 col-lg-12">
      
        <?php echo csrf_field(); ?>
      <div class="card">
          <div class="card-header">
            <h4>Tavar <?php echo e($product->name); ?></h4>
            <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-primary">Orqaga</a>
          </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table">
              <tr>
                <th>Nomi</th><td><?php echo e($product->name); ?></td>
              </tr>
              <tr>
                <th>Rasmi</th><td><img width="200" src="/site/products/images/<?php echo e($product->image); ?>"></td>
              </tr>
              <tr>
                <th>Markasi</th>
                <td>
                  <?php echo e($product->markasi); ?>

                </td>
              </tr>
              <tr>
                <th>Brendi</th>
                <td>
                  <?php echo e($product->brendi); ?>

                </td>
              </tr>
              <tr>
                <th>Modeli</th>
                <td>
                  <?php echo e($product->model); ?>

                </td>
              </tr>
              <tr>
                <th>Dubl/Org</th>
                <td>
                  <?php echo e($product->Org_Dub); ?>

                </td>
              </tr>
              <tr>
                <th>Part no'mer</th>
                <td>
                  <?php echo e($product->part_number); ?>

                </td>
              </tr>
              <tr>
                <th>Soni</th>
                <td>
                  <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($type->soni); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
              </tr>
              <tr>
                <th>Narxi</th>
                <td>
                  <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($type->olingan_narxi); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
              </tr>
              <tr>
                <th>Olingan narx</th>
                <td>
                  <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($type->weight); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
              </tr>
              <tr>
                <th>yuk narxi</th>
                <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($type->yuk_narxi); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tr>
              <tr>
                <th>Kg</th>
                <td>
                  <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($type->weight); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
              </tr>
              <tr>
                <th>To'liq narx</th>
                <<td>
                  <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($type->full_price); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
              </tr>
              <tr>
                <th>chiqqan yili</th>
                <td>
                  <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($type->chiqqan_yili); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
              </tr>
              <tr>
                <th>kelgan vaqti</th>
                <td>
                  <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($type->kelgan_yili); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
              </tr>
              <tr>
                <th>O'lchami</th>
                <td>
                  <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($type->size); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
              </tr>

              <tr>
                <th>Qo'shilgan vaqti</th><td><?php echo e($product->created_at); ?></td>
              </tr>
            </table>
          </div>
        </div>
      </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\AvtoZapchast\resources\views/admin/products/show.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title'); ?>
    Ombor
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12 col-md-12 col-lg-12">
      
        <?php echo csrf_field(); ?>
      <div class="card">
          <div class="card-header">
            <h4>Ombor <?php echo e($warehouse->name); ?></h4>
            <a href="<?php echo e(route('admin.warehouses.index')); ?>" class="btn btn-primary">Orqaga</a>
          </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table">
              <tr>
                <th>Nomi</th><td><?php echo e($warehouse->name); ?></td>
              </tr>
              <tr>
                <th>Magazin</th><td><?php echo e($warehouse->shop->name_uz); ?></td>
              </tr>
              <tr>
                <th>Qo'shilgan vaqti</th><td><?php echo e($warehouse->created_at); ?></td>
              </tr>
            </table>
          </div>
        </div>
      </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\AvtoZapchast\resources\views/admin/warehouses/show.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title'); ?>
    Adminlar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
              <div class="col-12 col-md-6 col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Adminlar</h4>
                    <div class="card-header-form">
                    	<a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary">Create</a>
                    </div>
                    
                  </div>
                  <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible show fade col-lg-4">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>×</span>
                        </button>
                        <?php echo e(session('success')); ?>

                      </div>
                    </div>
                    <?php endif; ?>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-bordered table-md">
                        <tbody><tr>
                          <th>#</th>
                          <th>Nomi</th>
                          <th>Email</th>
                          <th>Phone</th>
                          <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($user->name); ?></td>
                          <td><?php echo e($user->email); ?></td>
                          <td><?php echo e($user->phone); ?></td>
                          <td>
                            
                            <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-info">Edit</a>
                            <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="btn btn-primary">View</a>
                            <form style="display: inline;" method="POST" action="<?php echo e(route('admin.users.destroy', $user->id)); ?>">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                              <input class="btn btn-danger" onclick="return confirm('Confirm <?php echo e($user->name); ?> delete')" type="submit" value="Delete">
                            </form>
                          </td>
                        </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody></table>
                    </div>
	                  </div>
                </div>
              </div>

            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\AvtoZapchast\resources\views/admin/users/index.blade.php ENDPATH**/ ?>
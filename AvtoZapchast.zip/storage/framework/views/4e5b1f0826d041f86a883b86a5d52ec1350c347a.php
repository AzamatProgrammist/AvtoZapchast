

<?php $__env->startSection('title'); ?>
    View user
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12 col-md-12 col-lg-12">
      
        <?php echo csrf_field(); ?>
      <div class="card">
          <div class="card-header">
            <h4>user ID <?php echo e($user->id); ?></h4>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-primary">Back</a>
          </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table">
              <tr>
                <th>Name</th><td><?php echo e($user->name); ?></td>
              </tr>
              <tr>
                <th>Phone</th><td><?php echo e($user->phone); ?></td>
              </tr>
              <tr>
                <th>Email</th><td><?php echo e($user->email); ?></td>
              </tr>
              <?php $__currentLoopData = $user->shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shops): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th>Shop</th><td><?php echo e($shops->name_uz); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th>Created At</th><td><?php echo e($user->created_at); ?></td>
              </tr>
            </table>
          </div>
        </div>
      </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\AvtoZapchast\resources\views/admin/users/show.blade.php ENDPATH**/ ?>
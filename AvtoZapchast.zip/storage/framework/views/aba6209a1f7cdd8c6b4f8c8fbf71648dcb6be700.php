

<?php $__env->startSection('title'); ?>
    Update taver
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12 col-md-12 col-lg-12">
      <form method="POST" action="<?php echo e(route('admin.products.update', $product->id)); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
      <div class="card">
          <div class="card-header">
            <h4>Tavarni o'zgartirish</h4>
          </div>
        <div class="card-body">
          <div class="form-group">
            <label>Name</label>
            <input type="text" value="<?php echo e($product->name); ?>" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback">Oh no! this is invalid.</div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          
          <div class="form-group">
            <label>Rasmi</label>
            <img src="/site/products/images/<?php echo e($product->image); ?>" width="100">

            <input type="hidden" name="old_image" class="form-control" value="<?php echo e($product->image); ?>">
            <input type="file" name="image" class="form-control" name="image">
          </div>

          <div class="form-group">
            <label>Markasi</label>
            <input type="text" value="<?php echo e($product->markasi); ?>" name="markasi" class="form-control">
          </div>
          <div class="form-group">
            <label>Brendi</label>
            <input type="text" value="<?php echo e($product->brendi); ?>" name="brendi" class="form-control">
          </div>
          <div class="form-group">
            <label>Modeli</label>
            <input type="text" value="<?php echo e($product->model); ?>" name="model" class="form-control">
          </div>
          <div class="form-group">
            <label>Org_Dub</label>
            <select name="Org_Dub" id="" class="form-control">
              <option value="<?php echo e($product->Org_Dub); ?>" <?php echo e($product->Org_dub=='Дубликат' ? 'selected' : ''); ?> ><?php echo e($product->Org_Dub); ?></option>
              <option value="Дубликат" >Дубликат</option>
              <option value="Оригинал" >Оригинал</option>
            </select>
          </div>
          <div class="form-group">
            <label>Part number</label>
            <input type="text" value="<?php echo e($product->part_number); ?>" name="part_number" class="form-control">
          </div>
          <div class="form-group">
            <label>Soni</label>
            <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="text" value="<?php echo e($type->soni); ?>" name="soni" class="form-control">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="form-group">
            <label>Sotish narxi</label>
            <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="text" value="<?php echo e($type->sotish_narxi); ?>" name="sotish_narxi" class="form-control">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="form-group">
            <label>Olingan narxi</label>
            <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="text" value="<?php echo e($type->olingan_narxi); ?>" name="olingan_narxi" class="form-control">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="form-group">
            <label>Yuk narxi</label>
            <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="text" value="<?php echo e($type->yuk_narxi); ?>" name="yuk_narxi" class="form-control">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="form-group">
            <label>Umumiy kg</label>
            <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="text" value="<?php echo e($type->weight); ?>" name="weight" class="form-control">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="form-group">
            <label>Chiqqan yili</label>
            <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="text" value="<?php echo e($type->chiqqan_yili); ?>" name="chiqqan_yili" class="form-control">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="form-group">
            <label>Kelgan vaqti</label>
            <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="text" value="<?php echo e($type->kelgan_yili); ?>" name="kelgan_yili" class="form-control">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="form-group">
            <label>Size</label>
            <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="text" value="<?php echo e($type->size); ?>" name="size" class="form-control">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="form-group">
            <label>Qo'shilgan vaqti</label>
            <?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="text" value="<?php echo e($type->created_at); ?>" name="created_at" class="form-control">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <input type="hidden" name="shop_id" value="<?php echo e($product->shop_id); ?>">
          <input type="hidden" name="ombor_id" value="<?php echo e($product->ombor_id); ?>">
          <input type="hidden" name="user_id" value="<?php echo e($product->user_id); ?>">
          <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
          <div class="card-footer text-right">
            <button class="btn btn-primary mr-1" type="submit">Update</button>
          </div>
        </div>
      </div>
    </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\AvtoZapchast\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>
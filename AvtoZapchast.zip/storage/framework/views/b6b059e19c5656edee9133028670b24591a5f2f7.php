

<?php $__env->startSection('title'); ?>
    Omborlar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
              <div class="col-12 col-md-6 col-lg-12">
                <div class="card">
                  <div class="card-body">
                    <div class="card-header">
                    <h4>Omborlar</h4>
                    <div class="card-header-form">
                      <div class="dropdown d-inline mr-2">
                      <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton"
                              data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Qo'shish
                            </button>
                      <div class="dropdown-menu">
                        <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="dropdown-item" href="<?php echo e(route('admin.warehouses.create', $shop->id)); ?>"><?php echo e($shop->name_uz); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>
                    </div>
                    </div>
                  </div>
                  <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible show fade col-lg-4">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>×</span>
                        </button>
                        <?php echo e(session('success')); ?>

                      </div>
                    </div>
                    <?php endif; ?>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-bordered table-md">
                        <tbody><tr>
                          <th>#</th>
                          <th>Nomi</th>
                          <th>Magazinlar</th>
                          <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($warehouse->name); ?></td>
                          <td><?php echo e($warehouse->shop->name_uz); ?></td>
                          <td>
                            
                            <a href="<?php echo e(route('admin.warehouses.edit', $warehouse->id)); ?>" class="btn btn-info">Edit</a>
                            <a href="<?php echo e(route('admin.warehouses.show', $warehouse->id)); ?>" class="btn btn-primary">View</a>
                            <form style="display: inline;" method="POST" action="<?php echo e(route('admin.warehouses.destroy', $warehouse->id)); ?>">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                              <input class="btn btn-danger" onclick="return confirm('Confirm <?php echo e($warehouse->name); ?> delete')" type="submit" value="Delete">
                            </form>
                          </td>
                        </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody></table>
                    </div>
                    </div>
                  <div class="card-footer text-right">
                    <nav class="d-inline-block">
                      <ul class="pagination mb-0">
                        <?php echo e($warehouses->links()); ?>

                      </ul>
                    </nav>
                  </div>
                </div>
              </div>

            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\AvtoZapchast\resources\views/admin/warehouses/index.blade.php ENDPATH**/ ?>
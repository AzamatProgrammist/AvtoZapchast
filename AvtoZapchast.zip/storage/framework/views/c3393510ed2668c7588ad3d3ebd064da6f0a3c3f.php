

<?php $__env->startSection('title'); ?>
    Do'konlar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
      <div class="col-12 col-md-6 col-lg-12">
        <div class="card">
          <div class="card-header">
            <h4>Dokonlar</h4>
            <div class="card-header-form">
              <a href="<?php echo e(route('admin.shops.create')); ?>" class="btn btn-primary">Yaratish</a>
            </div>
            
          </div>
          <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible show fade col-lg-4">
              <div class="alert-body">
                <button class="close" data-dismiss="alert">
                  <span>×</span>
                </button>
                <?php echo e(session('success')); ?>

              </div>
            </div>
            <?php endif; ?>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered table-md">
                <tbody><tr>
                  <th>#</th>
                  <th>Nomi</th>
                  <th>Admini</th>
                  <th>Action</th>
                </tr>
                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($shop->name_uz); ?></td>
                  <td><?php echo e($shop->admin); ?></td>
                  <td>
                    
                    <a href="<?php echo e(route('admin.shops.edit', $shop->id)); ?>" class="btn btn-info">Edit</a>
                    <a href="<?php echo e(route('admin.shops.show', $shop->id)); ?>" class="btn btn-primary">View</a>
                    <form style="display: inline;" method="POST" action="<?php echo e(route('admin.shops.destroy', $shop->id)); ?>">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                      <input class="btn btn-danger" onclick="return confirm('Confirm <?php echo e($shop->name_uz); ?> delete')" type="submit" value="Delete">
                    </form>
                  </td>
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody></table>
            </div>
            </div>
          <div class="card-footer text-right">
            <nav class="d-inline-block">
              <ul class="pagination mb-0">
                <?php echo e($shops->links()); ?>

              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\AvtoZapchast\resources\views/admin/shops/index.blade.php ENDPATH**/ ?>
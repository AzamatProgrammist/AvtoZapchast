

<?php $__env->startSection('title'); ?>
    yangi tavar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12 col-md-12 col-lg-12">
      <form method="POST" action="<?php echo e(route('admin.products.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
      <div class="card">
          <div class="card-header">
            <h4>Yangi tavar qo'shish</h4>
          </div>
        <div class="card-body">
          <div class="form-group">
            <label>Name</label>
            <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback">Oh no! This is invalid.</div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label>Orig/Dubl</label>
            <select name="Org_Dub" id="" class="form-control">
              <option>Tanlang Orig/Dubl</option>
              <option value="Оригинал">Оригинал</option>
              <option value="Дубликат">Дубликат</option>
            </select>
          </div>
          <div class="form-group">
            <label>Part Number</label>
            <input type="text" name="part_number" class="form-control">
          </div>
          <div class="form-group">
            <label>Rasmi</label>
            <input type="file" name="image" class="form-control">
          </div>
          <div class="form-group">
            <label>Modeli</label>
            <input type="text" name="model" class="form-control">
          </div>
          <div class="form-group">
            <label>Brendi</label>
            <input type="text" name="brendi" class="form-control">
          </div>
          <div class="form-group">
            <label>Markasi</label>
            <input type="text" name="markasi" class="form-control">
          </div>
          <div class="form-group">
            <label>Chiqqan yili</label>
            <input type="date" name="chiqqan_yili" class="form-control">
          </div>
          <div class="form-group">
            <label>Kelgan vaqti</label>
            <input type="date" name="kelgan_yili" class="form-control">
          </div>
          <div class="form-group">
            <label>Size</label>
            <input type="text" name="size" class="form-control">
          </div>
          <div class="form-group">
            <label>Olingan narxi($)</label>
            <input type="number" name="olingan_narxi" class="form-control" placeholder="dollirdaa kiriting">
          </div>
          <div class="form-group">
            <label>Sotilish narxi</label>
            <input type="text" name="sotish_narxi" class="form-control">
          </div>
          <div class="form-group">
            <label>Umumiy og'irligi</label>
            <input type="number" name="weight" class="form-control" placeholder="umumiy og'irligi">
          </div>
          <div class="form-group">
            <label>Yuk narxi($)</label>
            <input type="number" name="yuk_narxi" class="form-control" placeholder="1 kg yuk narxi dollirdaa">
          </div>
          <div class="form-group">
            <label>Soni</label>
            <input type="text" name="soni" class="form-control">
          </div>
          <div class="form-group">
            <label>Shops</label>
            <select name="shop_id" id="" class="form-control">
              <option>Select Shop</option>
              <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($shop->id); ?>"><?php echo e($shop->name_uz); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group">
            <label>Ombor</label>
            <select name="ombor_id" id="" class="form-control">
              <option>Select Ombor</option>
              <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $shop->warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="card-footer text-right">
            <button class="btn btn-primary mr-1" type="submit">Save</button>
          </div>
        </div>
      </div>
    </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\AvtoZapchast\resources\views/admin/products/create.blade.php ENDPATH**/ ?>